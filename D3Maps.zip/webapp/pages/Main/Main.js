/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/*
 * This function will be invoked when any of this prefab's property is changed
 * @key: property name
 * @newVal: new value of the property
 * @oldVal: old value of the property
 */
Prefab.onPropertyChange = function(key, newVal, oldVal) {
    debugger
    switch (key) {
        case 'dataset':
            Prefab.datafield = 'name'; //hardcoded
            Prefab.labelfield = 'customLabel'; //hardcoded

            generateDataset(newVal);

            if (Prefab.map) { //if map has been previously initialized
                console.log("D3Maps: --- Datamap re-initialized ---");

                Prefab.map.options.customLabelText = {};
                resetLabels();

                Prefab.map.options.fills = Prefab.colormap;
                console.log('D3Maps: colormap keys (after) ', _.keys(Prefab.map.options.fills));
                //console.log("D3Maps: Prefab data after re-initialized ----", Prefab.data);
                Prefab.map.updateChoropleth(Prefab.data, {
                    reset: true
                });
                generateLabels();

                if (Prefab.showbubbles)
                    generateBubbles();

                if (Prefab.legend) {
                    $($('.datamaps-legend')).empty(); //hack, cleanup of previous legend
                    Prefab.map.legend();
                }
            }
            break;
        case 'colormap':
            console.log('D3Maps: colormap keys, values ', _.keys(newVal), _.values(newVal));
            break;
        default:
            // console.log('#Property change ' + key + '=' + newVal);
            break;
    }
};


Prefab.onReady = function() {
    console.log("D3Maps: --- Datamap Initializing ---");

    initDataMap();
};

function initDataMap() {
    var mapCtr = Prefab.Widgets.mapContainer.$element[0];
    // this method will be triggered post initialization of the prefab.
    if (Prefab.scope === 'world') {
        initWorldMap(mapCtr);
    }
    // India map
    if (Prefab.scope === 'india') {
        initIndiaMap(mapCtr);
    }

    //draw bubbles for bombs
    if (Prefab.showbubbles)
        generateBubbles();
    if (Prefab.legend)
        Prefab.map.legend();
}

function initWorldMap(mapCtr) {
    Prefab.map = new Datamap({
        element: mapCtr,
        scope: Prefab.scope,
        fills: Prefab.colormap, //Any fill key, HIGH, LOW, MEDIUM, MAJOR, MINOR
        //height: Prefab.height,
        //width: Prefab.width,
        data: Prefab.data,
        //customTemplate: Prefab.detailstemplate,
        done: function(datamap) {
            console.log("D3Maps: Data Map (world) initialization completed...");
            //datamap.svg.call(d3.behavior.zoom().on("zoom", redrawMap));
            Prefab.datamap = datamap;
            //Prefab.zoom = d3.behavior.zoom().scaleExtent([1, 8]).on("zoom", zoomed);

            // function redrawMap() {
            //     debugger
            //     console.log("inside refraw----", d3);
            //     datamap.svg.selectAll("g").attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
            // }
            Prefab.datamap = datamap;
        },
        geographyConfig: {
            popupOnHover: Prefab.showdetails,
            //highlightOnHover: Prefab.highlight ? true : false,
            // highlightFillColor: Prefab.highlight,
            highlightBorderColor: Prefab.highlight,
            highlightBorderOpacity: 0.5,
            popupTemplate: function(geography, data) {
                return data["detailstemplate"];
            }
        },
        responsive: true
    });

    generateLabels();
}

function initIndiaMap(mapCtr) {
    Prefab.map = new Datamap({
        element: mapCtr,
        scope: Prefab.scope,
        //height: Prefab.height,
        geographyConfig: {
            popupOnHover: Prefab.showdetails,
            highlightOnHover: true,
            borderColor: '#444',
            borderWidth: 0.5,
            dataUrl: 'https://rawgit.com/Anujarya300/bubble_maps/master/data/geography-data/india.topo.json',
            highlightBorderColor: Prefab.highlight,
            highlightBorderOpacity: 0.5,
            popupTemplate: function(geography, data) {
                return data["detailstemplate"];
            }
            //dataJson: topoJsonData
        },
        fills: Prefab.colormap,
        data: Prefab.data,
        done: function(datamap) {
            console.log("D3Maps: Data Map (India) initialization completed...");
        },
        setProjection: function(element) {
            var lat, lon, scaleval;
            if (window.matchMedia("screen and (max-width: 480px)").matches) {
                lat = 118.9629;
                lon = 23.5937;
                scaleval = 500;
            } else if (window.matchMedia("screen and (max-width: 640px)").matches) {
                lat = 96.9629;
                lon = 23.5937;
                scaleval = 700;
            } else if (window.matchMedia("screen and (max-width: 800px)").matches) {
                lat = 104.9629;
                lon = 23.5937;
                scaleval = 650;
            } else if (window.matchMedia("screen and (max-width: 1200px)").matches) {
                lat = 96.9629;
                lon = 23.5937;
                scaleval = 750;
            } else {
                lat = 84.9629;
                lon = 23.5937;
                scaleval = 1000;
            }
            var projection = d3.geo.mercator()
                .center([lat, lon]) // always in [East Latitude, North Longitude]
                .scale(scaleval);
            var path = d3.geo.path().projection(projection);
            return {
                path: path,
                projection: projection
            };
        },
        responsive: true
    });
    generateLabels();
}

//generate dataset for datamap, call on property init()
function generateDataset(dset) {
    if (Prefab.scope === 'india') {
        Prefab.data = {};
    } else {
        Prefab.data = [];
    }
    Prefab.labeldata = {};
    if (dset && Prefab.datafield) {
        var mainKey = [];

        var field = Prefab.datafield.split('.');
        var lblfield = Prefab.labelfield.split('.');
        console.log('D3Maps: field -> ' + field);
        console.log('D3Maps: labelfield -> ' + lblfield);
        _.forEach(dset, function(value, key) {
            mainKey = field.length > 1 ? value[field[0]][field[1]] : value[field[0]];
            Prefab.data[mainKey] = value;
            // Prefab.data[mainKey].numberOfThings = value['numberOfThings'];
            //console.log(Prefab.data + '=> ' + _.keys(Prefab.data) + ',' + _.values(Prefab.data));

            var labelKey = lblfield.length > 1 ? value[lblfield[0]][lblfield[1]] : value[lblfield[0]];
            if (labelKey)
                Prefab.labeldata[mainKey] = labelKey;
            //console.log('labelkey->' + mainKey + '=' + labelKey);
        });
    }
}

function resetLabels() {
    var stdLabelKeys = {};
    if (Prefab.scope === 'india') {
        stdLabelKeys = _.keys(Prefab.Variables.indiaStateCodes.dataSet);
    } else {
        stdLabelKeys = Prefab.datamap.worldTopo.objects.world.geometries;
    }

    var labels = {};
    _.forEach(stdLabelKeys, function(value) {
        var key = (Prefab.scope === 'india') ? value : value.id;
        labels[key] = ' ';
    });
    Prefab.map.labels({
        'customLabelText': labels
    });
    $($('.labels')).empty(); //hack
    console.log('D3Maps: labels after reset -> ', _.values(Prefab.map.options.customLabelText));
}

//generates custom labels for countries
function generateLabels() {
    var stdLabelKeys = {};
    if (Prefab.scope === 'india') {
        stdLabelKeys = _.keys(Prefab.Variables.indiaStateCodes.dataSet);
    } else {
        stdLabelKeys = Prefab.datamap.worldTopo.objects.world.geometries;
    }

    if (Prefab.labeldata) {
        var countryList = {},
            labelKeys = [];
        //get all keys from the label data
        _.forEach(Prefab.labeldata, function(value, key) {
            labelKeys.push(key);
        });
        //console.log("D3Maps: labelkeys ", labelKeys);
        //get all countries to prepare the list of key and value for labels
        _.forEach(stdLabelKeys, function(value) {
            var key = (Prefab.scope === 'india') ? value : value.id;
            _.includes(labelKeys, key) ? countryList[key] = key : countryList[key] = ' ';
        });
        console.log('D3Maps: countryLabels ' + _.values(countryList));
        Prefab.map.labels({
            'customLabelText': countryList
        });
    }
}

function generateBubbles() {
    //console.log('function for bubbles data=' + _.isArray(Prefab.dataset));
    if (Prefab.scope === 'india' && Prefab.dataset) {
        const bubblearray = [];
        _.forEach(Prefab.dataset, function(obj) {
            bubblearray.push(obj);
        });
        console.log("D3Maps: Bubble array -->", bubblearray);
        Prefab.map.bubbles(bubblearray, {
            popupOnHover: true,
            highlightOnHover: Prefab.bubblecolor ? true : false,
            highlightFillColor: Prefab.bubblecolor,
            highlightBorderColor: Prefab.bubblecolor,
            highlightBorderOpacity: 0.4,
            popupTemplate: function(geo, data) {
                return data["detailstemplate"];
            }
        });
    } else {
        Prefab.map.bubbles(Prefab.dataset, {
            popupOnHover: true,
            highlightOnHover: Prefab.bubblecolor ? true : false,
            highlightFillColor: Prefab.bubblecolor,
            highlightBorderColor: Prefab.bubblecolor,
            highlightBorderOpacity: 0.3,
            popupTemplate: function(geo, data) {
                return data["detailstemplate"];
            }
        });
    }
}

// $(window).on('resize', function() {
//     Prefab.datamap.resize();
// });

// $(document).ready(function() {
//     setTimeout(function() {
//         var elementslength = $($('.bubbles > circles')).length;
//         for (var i = 0; i < elementslength; i++) {
//             $($('.bubbles > circles'))[i].attr('style', 'fill: red')
//         }
//     }, 4000);
// });
